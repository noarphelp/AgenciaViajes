package com.PF.Reservas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservasApplicationTests {

	@Test
	void contextLoads() {
	}

}
